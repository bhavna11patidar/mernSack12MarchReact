import React, { Component } from 'react'

export default class ClassComponent1 extends Component {
  render() {
    return (
      <div>ClassComponent1</div>
    )
  }
}
