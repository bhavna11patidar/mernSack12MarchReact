import React from 'react'

export default function FunctionalComponent() {
  return (
    <div>functional Component</div>
  )
}
