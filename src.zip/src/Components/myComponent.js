import React from 'react'

export default function MyComponent() {
  return (
    <div>myComponent</div>
  )
}

export function Abc(){
    return(
        <h1>Hello Inside ABC</h1>
    )
}

export function Test(){
    return(
        <h1>Hello Inside Test</h1>
    )
}
